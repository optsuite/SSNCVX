function C = uminus(A)
    C = unaryOperation(A, @uminus);
end