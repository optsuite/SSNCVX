function C = minus(A, B)
    C = elementwiseOperation(A, B, @minus);
end