function C = full(A)
    C = unaryOperation(A, @full);
end