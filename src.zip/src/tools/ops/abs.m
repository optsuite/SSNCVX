function C = abs(A)
    C = unaryOperation(A, @abs);
end