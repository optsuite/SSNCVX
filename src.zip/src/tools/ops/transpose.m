function C = transpose(A)
    C = unaryOperation(A, @transpose);
end