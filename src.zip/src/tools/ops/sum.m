function C = sum(A)
    C = unaryOperation(A, @sum);
end