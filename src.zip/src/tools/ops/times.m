function C = times(A, B)
    C = elementwiseOperation(A, B, @times);
end