
function C = mtimes(A, B)  
    C = elementwiseOperation(A, B, @times);
end