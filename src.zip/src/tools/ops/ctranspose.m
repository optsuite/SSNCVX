function C = ctranspose(A)
    C = unaryOperation(A, @ctranspose);
end